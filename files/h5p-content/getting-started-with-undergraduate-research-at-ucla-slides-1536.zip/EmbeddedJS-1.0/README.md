Embedded JS
==========

Used in other libraries as template language.

## License

[EJS Embedded JavaScript Framework](https://code.google.com/p/embeddedjavascript/) licensed under [MIT License](http://www.opensource.org/licenses/mit-license.php).

